import React,{Component} from 'react'

import LocatePlace from './components/LocatePlace'


export default class App extends Component{
  render(){
    return <LocatePlace/>
  }
}